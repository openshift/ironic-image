=====================
Configuration Options
=====================

The following is an overview of all available configuration options in
Ironic. For a sample configuration file, refer to
:doc:`sample-config`.

.. show-options::
   :config-file: tools/config/ironic-config-generator.conf
