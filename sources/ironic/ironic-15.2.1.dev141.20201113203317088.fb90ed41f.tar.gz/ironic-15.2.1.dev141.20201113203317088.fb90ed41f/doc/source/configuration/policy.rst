========
Policies
========

The following is an overview of all available policies in Ironic.  For
a sample configuration file, refer to :doc:`sample-policy`.

.. show-policy::
   :config-file: tools/policy/ironic-policy-generator.conf
