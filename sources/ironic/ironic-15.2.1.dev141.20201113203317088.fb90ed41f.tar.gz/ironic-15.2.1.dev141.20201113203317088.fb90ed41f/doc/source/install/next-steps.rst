.. _next-steps:

==========
Next steps
==========

Your OpenStack environment now includes the Bare Metal service.
